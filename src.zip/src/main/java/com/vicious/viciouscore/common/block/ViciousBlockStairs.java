package com.vicious.viciouscore.common.block;

import net.minecraft.block.BlockStairs;
import net.minecraft.block.state.IBlockState;

public class ViciousBlockStairs extends BlockStairs {
    protected ViciousBlockStairs(IBlockState modelState) {
        super(modelState);
    }
}
